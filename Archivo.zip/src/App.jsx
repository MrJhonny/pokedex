import { useState, useEffect } from 'react'
import './App.css'
import Header from './components/Header';
import Home from './pages/Home';
import Loader from './components/Loader';
import UpArrow from './components/UpArrow';

function App() {
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPokemon, setSelectedPokemon] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000); // 2 segundos

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {loading ? (
        <Loader />
      ) : (
        <>
          <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <div className={`header-wrapper ${selectedPokemon ? 'behind-bigcard' : ''}`}>
              <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} bigCardOpen={!!selectedPokemon} />
            </div>
            <Home
              searchQuery={searchQuery}
              selectedPokemon={selectedPokemon}
              setSelectedPokemon={setSelectedPokemon}
            />
            {!selectedPokemon && <UpArrow />}
          </div>
        </>
      )}
    </>
  );
}

export default App
